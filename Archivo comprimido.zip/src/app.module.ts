import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ClientController } from './client/client.controller';
import { Client } from './client/client.entity';
import { Siniestro } from './polizas/siniestros/siniestros.entity';
import { SiniestrosController } from './polizas/siniestros/siniestros.controller';

@Module({
  imports: [
    ConfigModule.forRoot(),
    TypeOrmModule.forRoot({
      type: 'mysql',
      host: process.env.MYSQLDB_HOST,
      username: process.env.MYSQLDB_USER,
      password: process.env.MYSQLDB_PASSWORD,
      database: process.env.MYSQLDB_DATABASE,
      autoLoadEntities: true,
      entities: [Client, Siniestro], //put in all the entities created
      synchronize: true,
    }),
    TypeOrmModule.forFeature([Client]),
  ],
  exports: [],
  controllers: [ClientController, SiniestrosController], //put in all the controllers created
  providers: [],
})
export class AppModule {}
