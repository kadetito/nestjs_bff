export const TABLE_ASEGURADOS = 'ins_asegurados';
export const TABLE_ASEGURADOS_FIELD_NAME = 'name';
export const TABLE_ASEGURADOS_FIELD_LASTNAME = 'lastname';
export const TABLE_ASEGURADOS_FIELD_EMAIL = 'email';
