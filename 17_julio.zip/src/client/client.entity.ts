import {
  TABLE_ASEGURADOS,
  TABLE_ASEGURADOS_FIELD_EMAIL,
  TABLE_ASEGURADOS_FIELD_LASTNAME,
  TABLE_ASEGURADOS_FIELD_NAME,
} from 'src/common /constants';
import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity({ name: TABLE_ASEGURADOS })
export class Client {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ name: TABLE_ASEGURADOS_FIELD_NAME })
  name: string;

  @Column({ name: TABLE_ASEGURADOS_FIELD_LASTNAME })
  lastname: string;

  @Column({ name: TABLE_ASEGURADOS_FIELD_EMAIL })
  email: string;
}
