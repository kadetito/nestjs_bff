import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ClientController } from './client/client.controller';
import { Client } from './client/client.entity';
import { Siniestro } from './polizas/siniestros/siniestros.entity';
import { SiniestrosController } from './polizas/siniestros/siniestros.controller';
import { User } from './users/user.entity';
import { UserController } from './users/user.controller';
import { AuthController } from './auth/auth.controller';
import { JwtModule } from '@nestjs/jwt';
import { Vehiculo } from './polizas/vehiculos/vehiculos.entity';
import { VehiculoController } from './polizas/vehiculos/vehiculos.controller';
import { Salud } from './polizas/salud/salud.entity';
import { SaludController } from './polizas/salud/salud.controller';
import { AgenteController } from './agentes/agente.controller';
import { Agente } from './agentes/agente.entity';

@Module({
  imports: [
    ConfigModule.forRoot(),
    TypeOrmModule.forRoot({
      type: 'mysql',
      host: process.env.MYSQLDB_HOST,
      username: process.env.MYSQLDB_USER,
      password: process.env.MYSQLDB_PASSWORD,
      database: process.env.MYSQLDB_DATABASE,
      autoLoadEntities: true,
      entities: [Client, Siniestro, User, Vehiculo, Salud, Agente], //put in all the entities created
      synchronize: true,
    }),
    TypeOrmModule.forFeature([Client, User, Vehiculo, Salud, Agente]),
    JwtModule.register({ secret: process.env.JWT_SECRETKEY }),
  ],
  exports: [],
  controllers: [
    ClientController,
    SiniestrosController,
    UserController,
    AuthController,
    VehiculoController,
    SaludController,
    AgenteController,
  ], //put in all the controllers created
  providers: [],
})
export class AppModule {}
