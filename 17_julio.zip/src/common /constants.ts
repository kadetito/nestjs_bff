export const TABLE_ASEGURADOS = 'ins_asegurados';
export const TABLE_ASEGURADOS_FIELD_NAME = 'name';
export const TABLE_ASEGURADOS_FIELD_LASTNAME = 'lastname';
export const TABLE_ASEGURADOS_FIELD_EMAIL = 'email';

export const TABLE_USERS = 'ins_users';
export const TABLE_USERS_FIELD_IDENTIFICADOR = 'identificador';
export const TABLE_USERS_FIELD_NAME = 'name';
export const TABLE_USERS_FIELD_LASTNAME = 'lastname';
export const TABLE_USERS_FIELD_USERNAME = 'username';
export const TABLE_USERS_FIELD_PASSWORD = 'password';

export const TABLE_AGENTE_FIELD_IDAGENTE = 'id_agente';
export const TABLE_AGENTE_FIELD_NUMAGENTE = 'num_agente';
export const TABLE_AGENTE_FIELD_NAMEAGENTE = 'name_agente';
export const TABLE_AGENTE_FIELD_LASTNAMEAGENTE = 'lastname_agente';
export const TABLE_AGENTE_FIELD_EMAILAGENTE = 'email_agente';
export const TABLE_AGENTE_FIELD_USERNAMEAGENTE = 'username_agente';
export const TABLE_AGENTE_FIELD_PASSWORDAGENTE = 'password_agente';

export const TABLE_POLIZA_VEHICULOS = 'ins_poliza_vehiculos';
export const TABLE_POLIZA_VEHICULOS_IDUSER = 'id_user';
export const TABLE_POLIZA_VEHICULOS_MARCA = 'marca';
export const TABLE_POLIZA_VEHICULOS_MODELO = 'modelo';
export const TABLE_POLIZA_VEHICULOS_MATRICULA = 'matricula';
export const TABLE_POLIZA_VEHICULOS_FECHA_FABRICACION = 'fecha_fabricacion';
export const TABLE_POLIZA_VEHICULOS_IDAGENTE = 'id_agente';

export const TABLE_POLIZA_SALUD = 'ins_poliza_salud';
export const TABLE_POLIZA_SALUD_IDUSER = 'id_user';
export const TABLE_POLIZA_SALUD_NUMPOLIZA = 'num_poliza';
export const TABLE_POLIZA_SALUD_FECHA_CREACION = 'fecha_creacion';
export const TABLE_POLIZA_SALUD_FECHA_FIN = 'fecha_fin';
export const TABLE_POLIZA_SALUD_IDAGENTE = 'id_agente';
