import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  HttpException,
  HttpStatus,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from './user.entity';
import * as bcrypt from 'bcrypt';

@Controller('users')
export class UserController {
  constructor(
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
  ) {}

  @Get()
  async getAllUsers(): Promise<User[]> {
    return this.userRepository.find();
  }

  @Get(':id')
  async getUserById(@Param('id') id: number): Promise<User> {
    return this.userRepository.findOne({ where: { id } });
  }

  @Post()
  async createUser(@Body() user: User): Promise<any> {
    const existingUser = await this.userRepository.findOne({
      where: { identificador: user.identificador },
    });

    if (existingUser) {
      throw new HttpException(
        {
          status: 'error',
          message: 'User already exists',
        },
        HttpStatus.CONFLICT,
      );
    }

    try {
      const hashedPassword = await bcrypt.hash(user.password, 10);
      user.password = hashedPassword;

      const createdUser = await this.userRepository.save(user);
      return {
        status: 'success',
        message: 'User created successfully',
        data: createdUser,
      };
    } catch (error) {
      throw new HttpException(
        {
          status: 'error',
          message: 'Failed to create user',
          error: error.message,
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  @Put(':id')
  async updateUser(@Param('id') id: number, @Body() user: User): Promise<any> {
    try {
      await this.userRepository.update(id, user);
      const updatedUser = await this.userRepository.findOne({ where: { id } });
      if (!updatedUser) {
        throw new HttpException(
          {
            status: 'error',
            message: 'User not found',
          },
          HttpStatus.NOT_FOUND,
        );
      }
      return {
        status: 'success',
        message: 'User updated successfully',
        data: updatedUser,
      };
    } catch (error) {
      throw new HttpException(
        {
          status: 'error',
          message: 'Failed to update user',
          error: error.message,
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  @Delete(':id')
  async deleteUser(@Param('id') id: number): Promise<any> {
    try {
      const deleteResult = await this.userRepository.delete(id);
      if (deleteResult.affected === 0) {
        throw new HttpException(
          {
            status: 'error',
            message: 'User not found',
          },
          HttpStatus.NOT_FOUND,
        );
      }
      return {
        status: 'success',
        message: 'User deleted successfully',
      };
    } catch (error) {
      throw new HttpException(
        {
          status: 'error',
          message: 'Failed to delete user',
          error: error.message,
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}
