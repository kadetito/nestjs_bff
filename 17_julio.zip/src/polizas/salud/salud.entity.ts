import {
  TABLE_POLIZA_SALUD,
  TABLE_POLIZA_SALUD_FECHA_CREACION,
  TABLE_POLIZA_SALUD_FECHA_FIN,
  TABLE_POLIZA_SALUD_IDAGENTE,
  TABLE_POLIZA_SALUD_IDUSER,
  TABLE_POLIZA_SALUD_NUMPOLIZA,
} from 'src/common /constants';
import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity({ name: TABLE_POLIZA_SALUD })
export class Salud {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ name: TABLE_POLIZA_SALUD_IDAGENTE })
  idAgente: number;

  @Column({ name: TABLE_POLIZA_SALUD_IDUSER })
  idUser: number;

  @Column({ name: TABLE_POLIZA_SALUD_NUMPOLIZA })
  numPoliza: string;

  @Column({ type: 'date', name: TABLE_POLIZA_SALUD_FECHA_CREACION })
  fechaCreacion: Date;

  @Column({ type: 'date', name: TABLE_POLIZA_SALUD_FECHA_FIN })
  fechaFin: Date;
}
