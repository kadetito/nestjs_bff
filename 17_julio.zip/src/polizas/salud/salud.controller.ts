import {
  Controller,
  Get,
  Post,
  Body,
  Put,
  Param,
  Delete,
  HttpException,
  HttpStatus,
} from '@nestjs/common';
import { Salud } from './salud.entity';

import { InjectRepository } from '@nestjs/typeorm';
import { Like, Repository } from 'typeorm';
import { User } from 'src/users/user.entity';
import { Agente } from 'src/agentes/agente.entity';

@Controller('salud')
export class SaludController {
  constructor(
    @InjectRepository(Salud)
    private readonly saludRepository: Repository<Salud>,

    @InjectRepository(User)
    private readonly userRepository: Repository<User>,

    @InjectRepository(Agente)
    private readonly agenteRepository: Repository<Agente>,
  ) {}

  @Get()
  async findAll(): Promise<Salud[]> {
    return this.saludRepository.find();
  }

  @Get(':id')
  async findOne(@Param('id') id: number): Promise<Salud> {
    return this.saludRepository.findOne({ where: { id } });
  }

  @Post()
  async create(@Body() salud: Salud): Promise<Salud> {
    return this.saludRepository.save(salud);
  }

  @Put(':id')
  async update(@Param('id') id: number, @Body() salud: Salud): Promise<Salud> {
    await this.saludRepository.update(id, salud);
    return this.saludRepository.findOne({ where: { id } });
  }

  @Delete(':id')
  async delete(@Param('id') id: string): Promise<void> {
    await this.saludRepository.delete(id);
  }

  @Post('buscar')
  async buscar(@Body() filtro: Partial<Salud>): Promise<any[]> {
    const { idUser, idAgente, numPoliza, fechaCreacion, fechaFin } = filtro;

    // Verificar si se proporciona al menos un parámetro de búsqueda
    if (!idUser && !idAgente && !numPoliza && !fechaCreacion && !fechaFin) {
      throw new HttpException(
        'Se requiere al menos un parámetro de búsqueda',
        HttpStatus.BAD_REQUEST,
      );
    }

    // Construir el objeto de consulta
    const where = {};
    if (idUser) where['idUser'] = idUser;
    if (idAgente) where['idAgente'] = idAgente;

    if (numPoliza) where['numPoliza'] = Like(`%${numPoliza}%`);
    if (fechaCreacion) where['fechaCreacion'] = Like(`%${fechaCreacion}%`);
    if (fechaFin) where['fechaFin'] = Like(`%${fechaFin}%`);

    const resultados = await this.saludRepository.find({ where });

    if (resultados.length === 0) {
      return ['Lo sentimos, no hay ningún resultado para su búsqueda'];
    }

    const saludConUsuarios = await Promise.all(
      resultados.map(async (salud) => {
        const userPromise = this.userRepository.findOne({
          where: { id: salud.idUser },
        });
        const agentePromise = this.agenteRepository.findOne({
          where: { id_agente: salud.idAgente },
        });

        const [user, agente] = await Promise.all([userPromise, agentePromise]);

        const { password, role, ...userWithoutSensitiveInfo } = user; // Prescindimos de la información sensible del User
        const { passwordAgente, ...agenteWithoutSensitiveInfo } = agente; // Prescindimos de la información sensible del Agente

        return {
          ...salud,
          user: userWithoutSensitiveInfo,
          agente: agenteWithoutSensitiveInfo,
        };
      }),
    );

    return saludConUsuarios;
  }
}
