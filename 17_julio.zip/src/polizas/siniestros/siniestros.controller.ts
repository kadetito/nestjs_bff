import { Controller, InternalServerErrorException } from '@nestjs/common';
import { Body, Delete, Get, Param, Put } from '@nestjs/common/decorators/http';
import axios from 'axios';
import { Siniestro } from './siniestros.entity';

/**
 *  API REMOTA
 *  Ejemplo de uso atacando un endpoint de una API externa
 *  Ideal para usar Nest como Backend for Frontend (BFF)
 *
 */

@Controller('siniestros')
export class SiniestrosController {
  @Get()
  async getSiniestrosData(): Promise<Siniestro[]> {
    const apiUrl = 'https://jsonplaceholder.typicode.com/posts'; // URL de la API HTTPS que devuelve JSON

    try {
      const response = await axios.get(apiUrl);
      const siniestrosData = response.data as Siniestro[];
      return siniestrosData;
    } catch (error) {
      console.error('Error al obtener los datos de la API:', error);
      throw new InternalServerErrorException();
    }
  }

  @Get(':id')
  async getSiniestroById(@Param('id') id: number): Promise<Siniestro> {
    const apiUrl = `https://jsonplaceholder.typicode.com/posts/${id}`;

    try {
      const response = await axios.get(apiUrl);
      const siniestroData = response.data as Siniestro;
      return siniestroData;
    } catch (error) {
      console.error('Error al obtener el siniestro:', error);
      throw new InternalServerErrorException();
    }
  }

  @Put(':id')
  async updateSiniestroById(
    @Param('id') id: number,
    @Body() updatedSiniestro: Siniestro,
  ): Promise<Siniestro> {
    const apiUrl = `https://jsonplaceholder.typicode.com/posts/${id}`;

    try {
      const response = await axios.put(apiUrl, updatedSiniestro);
      const updatedData = response.data as Siniestro;
      return updatedData;
    } catch (error) {
      console.error('Error al actualizar el siniestro:', error);
      throw new InternalServerErrorException();
    }
  }

  @Delete(':id')
  async deleteSiniestroById(@Param('id') id: number): Promise<void> {
    const apiUrl = `https://jsonplaceholder.typicode.com/posts/${id}`;

    try {
      await axios.delete(apiUrl);
    } catch (error) {
      console.error('Error al eliminar el siniestro:', error);
      throw new InternalServerErrorException();
    }
  }
}
