import {
  Controller,
  Get,
  Post,
  Body,
  Put,
  Param,
  Delete,
  HttpException,
  HttpStatus,
} from '@nestjs/common';
import { Vehiculo } from './vehiculos.entity';

import { InjectRepository } from '@nestjs/typeorm';
import { Like, Repository } from 'typeorm';
import { User } from 'src/users/user.entity';
import { Agente } from 'src/agentes/agente.entity';

/**
 *  API LOCAL DOCKER
 *  Ejemplo de uso atacando una bbdd local/remota levantada en docker
 *
 *
 */
@Controller('vehiculos')
export class VehiculoController {
  constructor(
    @InjectRepository(Vehiculo)
    private readonly vehiculoRepository: Repository<Vehiculo>,

    @InjectRepository(User)
    private readonly userRepository: Repository<User>,

    @InjectRepository(Agente)
    private readonly agenteRepository: Repository<Agente>,
  ) {}

  @Get()
  async findAll(): Promise<Vehiculo[]> {
    return this.vehiculoRepository.find();
  }

  @Get(':id')
  async findOne(@Param('id') id: number): Promise<Vehiculo> {
    return this.vehiculoRepository.findOne({ where: { id } });
  }

  @Post()
  async create(@Body() vehiculo: Vehiculo): Promise<Vehiculo> {
    return this.vehiculoRepository.save(vehiculo);
  }

  @Put(':id')
  async update(
    @Param('id') id: number,
    @Body() vehiculo: Vehiculo,
  ): Promise<Vehiculo> {
    await this.vehiculoRepository.update(id, vehiculo);
    return this.vehiculoRepository.findOne({ where: { id } });
  }

  @Delete(':id')
  async delete(@Param('id') id: string): Promise<void> {
    await this.vehiculoRepository.delete(id);
  }

  @Post('buscar')
  async buscar(@Body() filtro: Partial<Vehiculo>): Promise<any[]> {
    const { idUser, idAgente, marca, modelo, matricula, fechaFabricacion } =
      filtro;

    // Verificar si se proporciona al menos un parámetro de búsqueda
    if (
      !idUser &&
      !idAgente &&
      !marca &&
      !modelo &&
      !matricula &&
      !fechaFabricacion
    ) {
      throw new HttpException(
        'Se requiere al menos un parámetro de búsqueda',
        HttpStatus.BAD_REQUEST,
      );
    }

    // Construir el objeto de consulta
    const where = {};
    if (idUser) where['idUser'] = idUser;
    if (idAgente) where['idAgente'] = idAgente;

    if (marca) where['marca'] = Like(`%${marca}%`);
    if (modelo) where['modelo'] = Like(`%${modelo}%`);
    if (matricula) where['matricula'] = Like(`%${matricula}%`);
    if (fechaFabricacion)
      where['fechaFabricacion'] = Like(`%${fechaFabricacion}%`);

    const resultados = await this.vehiculoRepository.find({ where });

    if (resultados.length === 0) {
      return ['Lo sentimos, no hay ningún resultado para su búsqueda'];
    }

    const vehiculosConUsuarios = await Promise.all(
      resultados.map(async (vehiculo) => {
        const userPromise = this.userRepository.findOne({
          where: { id: vehiculo.idUser },
        });
        const agentePromise = this.agenteRepository.findOne({
          where: { id_agente: vehiculo.idAgente },
        });

        const [user, agente] = await Promise.all([userPromise, agentePromise]);

        const { password, role, ...userWithoutSensitiveInfo } = user; // Prescindimos de la información sensible del User
        const { passwordAgente, ...agenteWithoutSensitiveInfo } = agente; // Prescindimos de la información sensible del Agente

        return {
          ...vehiculo,
          user: userWithoutSensitiveInfo,
          agente: agenteWithoutSensitiveInfo,
        };
      }),
    );

    return vehiculosConUsuarios;
  }
}
