import {
  TABLE_POLIZA_VEHICULOS,
  TABLE_POLIZA_VEHICULOS_IDUSER,
  TABLE_POLIZA_VEHICULOS_MARCA,
  TABLE_POLIZA_VEHICULOS_MODELO,
  TABLE_POLIZA_VEHICULOS_MATRICULA,
  TABLE_POLIZA_VEHICULOS_FECHA_FABRICACION,
  TABLE_POLIZA_VEHICULOS_IDAGENTE,
} from 'src/common /constants';
import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity({ name: TABLE_POLIZA_VEHICULOS })
export class Vehiculo {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ name: TABLE_POLIZA_VEHICULOS_IDAGENTE })
  idAgente: number;

  @Column({ name: TABLE_POLIZA_VEHICULOS_IDUSER })
  idUser: number;

  @Column({ name: TABLE_POLIZA_VEHICULOS_MARCA })
  marca: string;

  @Column({ name: TABLE_POLIZA_VEHICULOS_MODELO })
  modelo: string;

  @Column({ name: TABLE_POLIZA_VEHICULOS_MATRICULA })
  matricula: string;

  @Column({ type: 'date', name: TABLE_POLIZA_VEHICULOS_FECHA_FABRICACION })
  fechaFabricacion: Date;
}
