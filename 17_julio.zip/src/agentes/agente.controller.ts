import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  HttpException,
  HttpStatus,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Agente } from './agente.entity';
import * as bcrypt from 'bcrypt';

@Controller('agentes')
export class AgenteController {
  constructor(
    @InjectRepository(Agente)
    private readonly agenteRepository: Repository<Agente>,
  ) {}

  @Get()
  async getAllAgentes(): Promise<Agente[]> {
    return this.agenteRepository.find();
  }

  @Get(':id_agente')
  async getAgenteById(@Param('id_agente') id_agente: number): Promise<Agente> {
    return this.agenteRepository.findOne({ where: { id_agente } });
  }

  @Post()
  async createAgente(@Body() agente: Agente): Promise<any> {
    const existingAgente = await this.agenteRepository.findOne({
      where: { numAgente: agente.numAgente },
    });

    if (existingAgente) {
      throw new HttpException(
        {
          status: 'error',
          message: 'Agente already exists',
        },
        HttpStatus.CONFLICT,
      );
    }

    try {
      const hashedPassword = await bcrypt.hash(agente.passwordAgente, 10);
      agente.passwordAgente = hashedPassword;

      const createdAgente = await this.agenteRepository.save(agente);
      return {
        status: 'success',
        message: 'Agente created successfully',
        data: createdAgente,
      };
    } catch (error) {
      throw new HttpException(
        {
          status: 'error',
          message: 'Failed to create user',
          error: error.message,
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  @Put(':id_agente')
  async updateAgente(
    @Param('id_agente') id_agente: number,
    @Body() agente: Agente,
  ): Promise<any> {
    try {
      await this.agenteRepository.update(id_agente, agente);
      const updatedAgente = await this.agenteRepository.findOne({
        where: { id_agente },
      });
      if (!updatedAgente) {
        throw new HttpException(
          {
            status: 'error',
            message: 'Agente not found',
          },
          HttpStatus.NOT_FOUND,
        );
      }
      return {
        status: 'success',
        message: 'Agente updated successfully',
        data: updatedAgente,
      };
    } catch (error) {
      throw new HttpException(
        {
          status: 'error',
          message: 'Failed to update user',
          error: error.message,
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  @Delete(':id_agente')
  async deleteAgente(@Param('id_agente') id_agente: number): Promise<any> {
    try {
      const deleteResult = await this.agenteRepository.delete(id_agente);
      if (deleteResult.affected === 0) {
        throw new HttpException(
          {
            status: 'error',
            message: 'Agente not found',
          },
          HttpStatus.NOT_FOUND,
        );
      }
      return {
        status: 'success',
        message: 'Agente deleted successfully',
      };
    } catch (error) {
      throw new HttpException(
        {
          status: 'error',
          message: 'Failed to delete user',
          error: error.message,
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}
