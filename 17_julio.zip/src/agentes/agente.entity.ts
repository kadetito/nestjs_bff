import {
  TABLE_AGENTE_FIELD_NUMAGENTE,
  TABLE_AGENTE_FIELD_NAMEAGENTE,
  TABLE_AGENTE_FIELD_LASTNAMEAGENTE,
  TABLE_AGENTE_FIELD_EMAILAGENTE,
  TABLE_AGENTE_FIELD_USERNAMEAGENTE,
  TABLE_AGENTE_FIELD_PASSWORDAGENTE,
} from 'src/common /constants';
import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity({ name: 'ins_agente' })
export class Agente {
  @PrimaryGeneratedColumn()
  id_agente: number;

  @Column({ name: TABLE_AGENTE_FIELD_NUMAGENTE })
  numAgente: string;

  @Column({ name: TABLE_AGENTE_FIELD_NAMEAGENTE })
  nameAgente: string;

  @Column({ name: TABLE_AGENTE_FIELD_LASTNAMEAGENTE })
  lastnameAgente: string;

  @Column({ name: TABLE_AGENTE_FIELD_EMAILAGENTE })
  emailAgente: string;

  @Column({ name: TABLE_AGENTE_FIELD_USERNAMEAGENTE })
  usernameAgente: string;

  @Column({ name: TABLE_AGENTE_FIELD_PASSWORDAGENTE })
  passwordAgente: string;
}
