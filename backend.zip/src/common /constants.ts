export const TABLE_ASEGURADOS = 'ins_asegurados';
export const TABLE_ASEGURADOS_FIELD_NAME = 'name';
export const TABLE_ASEGURADOS_FIELD_LASTNAME = 'lastname';
export const TABLE_ASEGURADOS_FIELD_EMAIL = 'email';

export const TABLE_USERS = 'ins_users';
export const TABLE_USERS_FIELD_IDENTIFICADOR = 'identificador';
export const TABLE_USERS_FIELD_NAME = 'name';
export const TABLE_USERS_FIELD_LASTNAME = 'lastname';
export const TABLE_USERS_FIELD_USERNAME = 'username';
export const TABLE_USERS_FIELD_PASSWORD = 'password';

export const TABLE_POLIZA_VEHICULOS = 'ins_poliza_vehiculos';
export const TABLE_POLIZA_VEHICULOS_IDUSER = 'id_user';
export const TABLE_POLIZA_VEHICULOS_MARCA = 'marca';
export const TABLE_POLIZA_VEHICULOS_MODELO = 'modelo';
export const TABLE_POLIZA_VEHICULOS_MATRICULA = 'matricula';
export const TABLE_POLIZA_VEHICULOS_FECHA_FABRICACION = 'fecha_fabricacion';
