import {
  Controller,
  Get,
  Post,
  Body,
  Put,
  Param,
  Delete,
} from '@nestjs/common';
import { Client } from './client.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

/**
 *  API LOCAL DOCKER
 *  Ejemplo de uso atacando una bbdd local/remota levantada en docker
 *
 *
 */
@Controller('clients')
export class ClientController {
  constructor(
    @InjectRepository(Client)
    private readonly clientRepository: Repository<Client>,
  ) {}

  @Get()
  async findAll(): Promise<Client[]> {
    return this.clientRepository.find();
  }

  @Get(':id')
  async findOne(@Param('id') id: number): Promise<Client> {
    return this.clientRepository.findOne({ where: { id } });
  }

  @Post()
  async create(@Body() client: Client): Promise<Client> {
    return this.clientRepository.save(client);
  }

  @Put(':id')
  async update(
    @Param('id') id: number,
    @Body() client: Client,
  ): Promise<Client> {
    await this.clientRepository.update(id, client);
    return this.clientRepository.findOne({ where: { id } });
  }

  @Delete(':id')
  async delete(@Param('id') id: string): Promise<void> {
    await this.clientRepository.delete(id);
  }
}
