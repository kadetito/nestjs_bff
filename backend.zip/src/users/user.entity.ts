import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity({ name: 'ins_users' })
export class User {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  identificador: string;

  @Column()
  name: string;

  @Column()
  lastname: string;

  @Column()
  username: string;

  @Column()
  password: string;
}
